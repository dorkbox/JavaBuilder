package org.bouncycastle.cert.ocsp;

public interface CertificateStatus
{
    public static final CertificateStatus GOOD = null;
}
