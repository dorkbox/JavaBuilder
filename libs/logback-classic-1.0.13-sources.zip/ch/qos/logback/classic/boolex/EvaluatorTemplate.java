package ch.qos.logback.classic.boolex;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class EvaluatorTemplate
  extends java.lang.Object  implements
    ch.qos.logback.classic.boolex.IEvaluator,    groovy.lang.GroovyObject {
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  boolean doEvaluate(ch.qos.logback.classic.spi.ILoggingEvent event) { return false;}
}
