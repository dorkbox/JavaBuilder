package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public interface ConfigurationContributor
 {
 java.util.Map<java.lang.String, java.lang.String> getMappings();
}
