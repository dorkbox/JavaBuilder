package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public class GafferConfigurator
  extends java.lang.Object  implements
    groovy.lang.GroovyObject {
public GafferConfigurator
(ch.qos.logback.classic.LoggerContext context) {}
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  ch.qos.logback.classic.LoggerContext getContext() { return (ch.qos.logback.classic.LoggerContext)null;}
public  void setContext(ch.qos.logback.classic.LoggerContext value) { }
protected  void informContextOfURLUsedForConfiguration(java.net.URL url) { }
public  void run(java.net.URL url) { }
public  void run(java.io.File file) { }
public  void run(java.lang.String dslText) { }
protected  org.codehaus.groovy.control.customizers.ImportCustomizer importCustomizer() { return (org.codehaus.groovy.control.customizers.ImportCustomizer)null;}
}
