package ch.qos.logback.classic.gaffer;

import java.lang.*;
import java.io.*;
import java.net.*;
import java.util.*;
import groovy.lang.*;
import groovy.util.*;

public enum NestingType
  implements
    groovy.lang.GroovyObject {
NA, SINGLE, AS_COLLECTION;
public static final ch.qos.logback.classic.gaffer.NestingType MIN_VALUE = null;
public static final ch.qos.logback.classic.gaffer.NestingType MAX_VALUE = null;
public  groovy.lang.MetaClass getMetaClass() { return (groovy.lang.MetaClass)null;}
public  void setMetaClass(groovy.lang.MetaClass mc) { }
public  java.lang.Object invokeMethod(java.lang.String method, java.lang.Object arguments) { return null;}
public  java.lang.Object getProperty(java.lang.String property) { return null;}
public  void setProperty(java.lang.String property, java.lang.Object value) { }
public  ch.qos.logback.classic.gaffer.NestingType next() { return (ch.qos.logback.classic.gaffer.NestingType)null;}
public  ch.qos.logback.classic.gaffer.NestingType previous() { return (ch.qos.logback.classic.gaffer.NestingType)null;}
public static final  ch.qos.logback.classic.gaffer.NestingType $INIT(java.lang.Object... para) { return (ch.qos.logback.classic.gaffer.NestingType)null;}
}
